//Numpy array shape [10]
//Min -0.339843750000
//Max 0.308593750000
//Number of zeros 0

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
bias19_t b19[10];
#else
bias19_t b19[10] = {-0.074218750, 0.308593750, -0.339843750, -0.162109375, 0.103515625, -0.001953125, -0.197265625, 0.253906250, 0.007812500, 0.011718750};
#endif

#endif
