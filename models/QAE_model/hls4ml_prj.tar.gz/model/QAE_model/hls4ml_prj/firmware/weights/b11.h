//Numpy array shape [2]
//Min 0.113461151719
//Max 0.213437706232
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
encoder_output_bias_t b11[2];
#else
encoder_output_bias_t b11[2] = {0.2134377062, 0.1134611517};
#endif

#endif
