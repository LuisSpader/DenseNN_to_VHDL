//Numpy array shape [15]
//Min -0.187500000000
//Max 0.375000000000
//Number of zeros 5

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[15];
#else
bias5_t b5[15] = {-0.1875, 0.1250, 0.1250, -0.1875, 0.0000, 0.2500, 0.1875, 0.1250, 0.0000, -0.1250, 0.3750, 0.0000, 0.0000, 0.1875, 0.0000};
#endif

#endif
